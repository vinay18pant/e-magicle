<?php
\stmLms\Classes\Models\StmOrderItems::init();
\stmLms\Classes\Models\StmStatistics::init();
\stmLms\Classes\Models\StmLmsPayout::init();
\stmLms\Classes\Models\StmCron::init();
