<?php

function stm_lms_questions_v2_load_template($tpl) {
    require STM_LMS_PATH . "/settings/questions_v2/tpls/{$tpl}.php";
}