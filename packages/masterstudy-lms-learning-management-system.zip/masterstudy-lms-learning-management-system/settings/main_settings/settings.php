<?php

require_once STM_LMS_PATH . '/settings/main_settings/general.php';
require_once STM_LMS_PATH . '/settings/main_settings/courses.php';
require_once STM_LMS_PATH . '/settings/main_settings/course.php';
require_once STM_LMS_PATH . '/settings/main_settings/routes.php';
require_once STM_LMS_PATH . '/settings/main_settings/payments.php';
require_once STM_LMS_PATH . '/settings/main_settings/google_api.php';
require_once STM_LMS_PATH . '/settings/main_settings/profiles.php';
require_once STM_LMS_PATH . '/settings/main_settings/certificates.php';
require_once STM_LMS_PATH . '/settings/main_settings/addons.php';
require_once STM_LMS_PATH . '/settings/main_settings/payout.php';
require_once STM_LMS_PATH . '/settings/main_settings/gdpr.php';
require_once STM_LMS_PATH . '/settings/main_settings/shortcodes.php';